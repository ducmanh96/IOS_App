//
//  ViewController.swift
//  kadai100M
//
//  Created by ducmanh on 2023/07/01.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource, UIPickerViewDelegate {
    
    //ImageViewオブジェクト
    
    @IBOutlet weak var caraImageView: UIImageView!
    
    //PickerViewオブジェクト

    @IBOutlet weak var charaSelectPickerView: UIPickerView!
    
    //キャラクター画像ファイル名管理用の配列
    var caraFileName = NSMutableArray()
    
    //キャラクター画像ファイル名
    var strCalaFileNameLeft:String = "gumma_left"
    var strCalaFileNameRight:String = "gumma_right"
    
    //PickerViewのタイトル表示用の配列
    var titleForPicker = NSMutableArray()
    
    //PickerViewの初期設定メソッド
    func initPickerView(){
        
        caraFileName[0] = "gumma"
        caraFileName[1] = "funa"
        titleForPicker[0] = "ぐんまちゃん"
        titleForPicker[1] = "ふなっしー"
        charaSelectPickerView.delegate = self
        charaSelectPickerView.dataSource = self
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return titleForPicker.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return titleForPicker[row] as? String
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        strCalaFileNameLeft =  caraFileName[row] as! String + "_left"
        strCalaFileNameRight =  caraFileName[row] as! String + "_right"
        caraImageView.image = UIImage(named:strCalaFileNameLeft)

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initPickerView()
        
    }
    
    // Segue実行時
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "toPlayViewControllerSegue") {
            let pvc = segue.destination as! PlayViewController
            pvc.strPlayCalaFileNameLeft = strCalaFileNameLeft
            pvc.strPlayCalaFileNameRight = strCalaFileNameRight
            print(strCalaFileNameLeft)
        }
    }

    @IBAction func backView(segue: UIStoryboardSegue) {
    }
    
}

