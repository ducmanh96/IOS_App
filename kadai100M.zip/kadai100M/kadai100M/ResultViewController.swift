//
//  ResultViewController.swift
//  kadai100M
//
//  Created by ducmanh on 2023/07/02.
//

import UIKit

class ResultViewController: UIViewController {

    //結果時間用
    var resultTimerCount = Double()
    
    @IBOutlet weak var resultTimerLabel: UILabel!
    
    
    //ランキング用
    @IBOutlet weak var highScore1Label: UILabel!
    
    @IBOutlet weak var highScore2Label: UILabel!
    
    
    @IBOutlet weak var highScore3Label: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //結果時間を表示する
        resultTimerLabel.text = String(format: "%.3f 秒", resultTimerCount)

        //ランキング算出
        self.checkHighScore()
        //ランキングを表示される
        self.rankingCalc()
    }
    
    //ランキングを表示するメソッド
    func rankingCalc(){
        //User Defaultsへアクセスする
        let defaults = UserDefaults.standard
        //1位から3位までのハイスコアを取得し、double型の変数に格納
        let highScore1 = defaults.double(forKey: "highScore1")
        let highScore2 = defaults.double(forKey: "highScore2")
        let highScore3 = defaults.double(forKey: "highScore3")

        //ハイスコアの存在を確認
        //もし、ハイスコアが存在する場合（0でない場合）は画面の一覧に表示
        if highScore1 != 0 {
            highScore1Label.text = String(format: "1位：%.3f 秒", highScore1)
        }
        if highScore2 != 0 {
            highScore2Label.text = String(format: "2位：%.3f 秒", highScore2)
        }
        if highScore3 != 0 {
            highScore3Label.text = String(format: "3位：%.3f 秒", highScore3)
        }
    }
    
    //ランキングを算出する
    func checkHighScore() {

        //User Defaultsへアクセスする
        let defaults = UserDefaults.standard
        //1位から3位までのハイスコアを取得し、double型の変数に格納
        var highScore1 = defaults.double(forKey: "highScore1")
        var highScore2 = defaults.double(forKey: "highScore2")
        var highScore3 = defaults.double(forKey: "highScore3")
        //（全てのハイスコアが既にある場合）比較の結果、今回のtimeが当てはまる順位に記録を挿入
        //1位より早い場合
        if highScore1 != 0 && resultTimerCount <= highScore1 {
            highScore3 = highScore2
            highScore2 = highScore1
            highScore1 = resultTimerCount
            //2位より早い場合
        } else if highScore2 != 0 && resultTimerCount <= highScore2 {
            highScore3 = highScore2
            highScore2 = resultTimerCount
            //3位より早い場合
        } else if highScore3 != 0 && resultTimerCount <= highScore3 {
            highScore3 = resultTimerCount
        }
            //ハイスコアがまだ格納されていない場合のtimeとの比較
            //1位がまだない場合
        else if highScore1 == 0 {
            highScore1 = resultTimerCount
            //2位がまだなく、1位より遅い場合
        } else if highScore2 == 0 && resultTimerCount >= highScore1 {
            highScore2 = resultTimerCount
            //3位がまだなく、2位より遅い場合
        } else if highScore3 == 0 && resultTimerCount >= highScore2 {
            highScore3 = resultTimerCount
        }
        //新しいハイスコアをUser Defaultsに保存
        defaults.set(highScore1, forKey: "highScore1")
        defaults.set(highScore2, forKey: "highScore2")
        defaults.set(highScore3, forKey: "highScore3")
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
