//
//  PlayViewController.swift
//  kadai100M
//
//  Created by ducmanh on 2023/07/02.
//

import UIKit

class PlayViewController: UIViewController {

    //キャラクターイメージ設定用変数
    @IBOutlet weak var playCalaImageView: UIImageView!
    var imageViewFlag = Bool()
    var strPlayCalaFileNameLeft = String()
    var strPlayCalaFileNameRight = String()

    @IBOutlet weak var gambaImageViewLeft: UIImageView!
    @IBOutlet weak var gambaImageViewRight: UIImageView!
    @IBOutlet weak var aseImageViewLeft: UIImageView!
    @IBOutlet weak var aseImageViewRight: UIImageView!
    @IBOutlet weak var goolteepImageView: UIImageView!
    
    //連打カウント用
    @IBOutlet weak var rendaCountLabel: UILabel!
    var rendaCount = Int()
    
    //タイマー関連の変数
    
    @IBOutlet weak var timeLabel: UILabel!
    var timer = Timer()
    var timerCount = Double()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //画像初期設定
        imageViewFlag = true
        playCalaImageView.image = UIImage(named: strPlayCalaFileNameLeft)
        
        gambaImageViewLeft.isHidden = true
        gambaImageViewRight.isHidden = true
        aseImageViewLeft.isHidden = true
        aseImageViewRight.isHidden = true
        goolteepImageView.isHidden = true
        
        //カウント初期化
        rendaCount = 0
        rendaCountLabel.text = String(format: "%dM",rendaCount)
        
        //タイマースタート
        timerCount = 0
        timer = Timer.scheduledTimer(
            timeInterval: 0.1,
            target: self,
            selector: #selector(PlayViewController.onTimer(timer:)),
            userInfo: nil,
            repeats: true
        )
        
    }
    
    //タイマーLabel更新メソッド
    @objc func onTimer(timer: Timer) {
        timerCount = timerCount + 0.1
        timeLabel.text = String(format: "%.1f", timerCount)
    }
    
    //連打ボタン
    @IBAction func pushedButtonRenda(_ sender: Any) {
        
        rendaCount = rendaCount + 1
        rendaCountLabel.text = String(format: "%dM",rendaCount)
        
        if rendaCount >= 100 {
            //タイマーを止める
            timer.invalidate()
            //画面遷移する
            //画面を遷移させる(segue(toResult)を実行させる)
            self.performSegue(withIdentifier: "toResultViewControllerSegue", sender: nil)
            
        }else{
            
            //画像の入れ替え処理を実行
            self.changeImageView()
        }
    }
    
    //画像ファイル変更メソッド
    func changeImageView(){
        
        if imageViewFlag {
            //キャラクターの画像を入れ替える(右)
            imageViewFlag = false
            playCalaImageView.image = UIImage(named: strPlayCalaFileNameRight)
        } else {
            //キャラクターの画像を入れ替える(左)
            imageViewFlag = true
            playCalaImageView.image = UIImage(named: strPlayCalaFileNameLeft)
        }
        
        //70M以上の場合
        if rendaCount > 70 {
            if imageViewFlag {
                aseImageViewLeft.isHidden = false
                aseImageViewRight.isHidden = true
            }else{
                aseImageViewLeft.isHidden = true
                aseImageViewRight.isHidden = false
            }
        }
        
        //80M以上の場合
        if rendaCount > 80{
            if imageViewFlag {
                gambaImageViewRight.isHidden = false
                gambaImageViewLeft.isHidden = true
            }else{
                gambaImageViewRight.isHidden = true
                gambaImageViewLeft.isHidden = false
            }
        }
        
        //90M以上の場合
        if rendaCount > 90 {
            goolteepImageView.isHidden = false
        }
        
    }
    
    //結果画面遷移
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        //結果表示画面へのSegueの発動
        if segue.identifier == "toResultViewControllerSegue" {
            let rvc = segue.destination as! ResultViewController
            rvc.resultTimerCount = timerCount
        }

    }

}
