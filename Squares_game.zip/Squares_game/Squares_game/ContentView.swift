import SwiftUI
import AVFoundation

enum GameLevel {
    case easy
    case normal
    case hard
}

class Square: Identifiable, ObservableObject {
    let id = UUID()
    @Published var color: Color
    @Published var isFlipped = false

    init(color: Color) {
        self.color = color
    }

    func flip() {
        isFlipped.toggle()
    }

    static func createSquares(for level: GameLevel) -> [Square] {
        var numberOfSquares = 0
        var colors: [Color] = [.red, .green, .blue, .yellow, .orange, .purple, .pink, .black]

        switch level {
        case .easy:
            numberOfSquares = 8
        case .normal:
            numberOfSquares = 12
        case .hard:
            numberOfSquares = 16
        }

        var squares: [Square] = []

        for _ in 0..<numberOfSquares / 2 {
            guard let color = colors.randomElement() else {
                break
            }

            squares.append(Square(color: color))
            squares.append(Square(color: color))

            // Remove the color from the available colors
            if let index = colors.firstIndex(of: color) {
                colors.remove(at: index)
            }
        }

        return squares.shuffled()
    }
}

class GameViewModel: ObservableObject {
    @Published var squares: [Square] = []
    @Published var selectedSquares: [Square] = []
    @Published var currentLevel: GameLevel = .easy
    @Published var timeRemaining: Int = 20
    @Published var isGameOverAlertPresented = false
    @Published var isYouWinAlertPresented = false
    @Published var wonRounds: Int = 0

    var correctSoundPlayer: AVAudioPlayer?
    var wrongSoundPlayer: AVAudioPlayer?
    var winSoundPlayer: AVAudioPlayer?
    var loseSoundPlayer: AVAudioPlayer?

    init() {
        squares = Square.createSquares(for: currentLevel)

        // 正解と不正解のための音声を初期化
        if let correctSoundURL = Bundle.main.url(forResource: "ping", withExtension: "mp3") {
            correctSoundPlayer = try? AVAudioPlayer(contentsOf: correctSoundURL)
        }
        if let wrongSoundURL = Bundle.main.url(forResource: "wrong", withExtension: "mp3") {
            wrongSoundPlayer = try? AVAudioPlayer(contentsOf: wrongSoundURL)
        }
        if let winSoundURL = Bundle.main.url(forResource: "win", withExtension: "mp3") {
            winSoundPlayer = try? AVAudioPlayer(contentsOf: winSoundURL)
        }
        if let loseSoundURL = Bundle.main.url(forResource: "lose", withExtension: "mp3") {
            loseSoundPlayer = try? AVAudioPlayer(contentsOf: loseSoundURL)
        }

        // カウントダウンを開始
        startTimer()
    }

    func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [self] timer in
            if timeRemaining > 0 {
                timeRemaining -= 1
            } else {
                // 時間切れ、負けの音を再生
                playLoseSound()
                timer.invalidate()
                isGameOverAlertPresented = true
            }
        }
    }

    func squareSelected(_ square: Square) {
        guard timeRemaining > 0 else {
            // 時間切れ
            return
        }

        if selectedSquares.count == 2 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                withAnimation {
                    if self.selectedSquares[0].color == self.selectedSquares[1].color {
                        // 正解の音を再生
                        self.playCorrectSound()

                        self.squares.removeAll { $0.isFlipped && (self.selectedSquares[0].id == $0.id || self.selectedSquares[1].id == $0.id) }
                        
                        // 勝利チェック
                        self.checkWin()
                    } else {
                        // 不正解の音を再生
                        self.playWrongSound()

                        self.selectedSquares.forEach { $0.flip() }
                    }

                    self.selectedSquares.removeAll()
                }
            }
        }

        if selectedSquares.count < 2 {
            square.flip()
            selectedSquares.append(square)
        }
    }

    func checkWin() {
        if squares.filter({ !$0.isFlipped }).isEmpty {
            // プレイヤーが全てのラウンドに勝利
            wonRounds += 1

            if currentLevel == .easy && wonRounds == 1 {
                // 中級レベルに移動
                currentLevel = .normal
                timeRemaining = 30
                squares = Square.createSquares(for: currentLevel)
            } else if currentLevel == .normal && wonRounds == 2 {
                // 難しいレベルに移動
                currentLevel = .hard
                timeRemaining = 45
                squares = Square.createSquares(for: currentLevel)
            } else if currentLevel == .hard && wonRounds == 3 {
                // プレイヤーが全てのラウンドに勝利
                playWinSound()
                isYouWinAlertPresented = true
            }
        }
    }

    func startNewGame() {
        timeRemaining = 20
        selectedSquares.removeAll()
        currentLevel = .easy
        wonRounds = 0
        squares = Square.createSquares(for: currentLevel)
        startTimer()
    }

    func playCorrectSound() {
        correctSoundPlayer?.play()
    }

    func playWrongSound() {
        wrongSoundPlayer?.play()
    }

    func playWinSound() {
        winSoundPlayer?.play()
    }

    func playLoseSound() {
        loseSoundPlayer?.play()
    }
}

struct SquareView: View {
    @ObservedObject var square: Square
    let onTap: () -> Void

    var body: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(square.isFlipped ? square.color : Color.gray)
            .aspectRatio(1, contentMode: .fill)
            .onTapGesture {
                onTap()
            }
            .rotation3DEffect(
                .degrees(square.isFlipped ? 180 : 0),
                axis: (x: 0.0, y: 1.0, z: 0.0)
            )
            .animation(.easeInOut(duration: 0.5)) // スムーズなフリップアニメーション
            .overlay(
                Text("🔒")
                    .font(.system(size: 40))
                    .foregroundColor(square.isFlipped ? .white : .black)
                    .opacity(square.isFlipped ? 1.0 : 0.0) // フリップされていない場合はテキストを非表示にする
            )
    }
}

struct ContentView: View {
    @StateObject private var viewModel = GameViewModel()

    var body: some View {
        VStack {
            Text("Squaresを合わせる！")
                .font(.custom("Avenir", size: 28)) // カスタムフォントを使用
                .foregroundColor(.white)
                .padding()

            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4)) {
                ForEach(viewModel.squares) { square in
                    SquareView(square: square, onTap: {
                        viewModel.squareSelected(square)
                    })
                    .padding(5)
                }
            }
            .padding()

            Text("残り時間： \(viewModel.timeRemaining) 秒")
                .font(.headline)
                .foregroundColor(.white)
                .padding()

            Button("新しいゲーム") {
                viewModel.startNewGame()
            }
            .font(.title)
            .foregroundColor(.white)
            .padding()
            .background(Color.blue)
            .cornerRadius(10)
            .padding(.bottom, 20)

        }
        .background(
            LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
        )
        .alert(isPresented: $viewModel.isYouWinAlertPresented) {
            Alert(
                title: Text("あなたの勝ち")
                    .font(.title),
                message: Text("おめでとうございます！ あなたはすべてのラウンドに勝ちました。")
                    .font(.body),
                dismissButton: .default(Text("新しいゲーム")) {
                    viewModel.startNewGame()
                }
            )
        }
        .alert(isPresented: $viewModel.isGameOverAlertPresented) {
            Alert(
                title: Text("ゲームオーバー")
                    .font(.title),
                message: Text("時間切れです。")
                    .font(.body),
                dismissButton: .default(Text("新しいゲーム")) {
                    viewModel.startNewGame()
                }
            )
        }
        .foregroundColor(.white)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
