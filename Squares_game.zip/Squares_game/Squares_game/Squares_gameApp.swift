//
//  Squares_gameApp.swift
//  Squares_game
//
//  Created by ducmanh on 2024/02/01.
//

import SwiftUI

@main
struct Squares_gameApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
